
const data=window.GROUP_DATA.metrics;
const changes=window.GROUP_DATA.changes;
const navs=[['overview','grid','Обзор группы'],['passport','users','Социальный паспорт'],['dynamics','chart','Динамика'],['ai','star','AI-ассистент'],['reports','file','Отчёты']];
const icon=n=>`<svg class="icon"><use href="#${n}"/></svg>`;
document.getElementById('nav').innerHTML=navs.map(([id,ic,name])=>`<button data-page="${id}" onclick="go('${id}')" class="${id==='overview'?'active':''}">${icon(ic)}${name}</button>`).join('');
function go(id){if(!navs.some(n=>n[0]===id))id='overview';document.querySelectorAll('.page').forEach(p=>p.classList.toggle('hidden',p.id!==id));document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===id));let name=navs.find(n=>n[0]===id)[2];document.getElementById('crumb').textContent=name;document.getElementById('title').textContent=id==='overview'?'Наша группа — РКИ-25':name+' · РКИ-25';history.replaceState(null,'','#'+id);window.scrollTo({top:0,behavior:'smooth'})}
function stat(label,value,ic,note){return `<section class="card stat"><div class="stathead">${label}${icon(ic)}</div><div class="value">${value}<small> чел.</small></div><div class="trend">${note}</div></section>`}
document.getElementById('stats').innerHTML=stat('Всего студентов',24,'users','Состав группы не изменился')+stat('Несовершеннолетние',15,'book','63% группы · −2 к сентябрю')+stat('Живут в общежитии',16,'grid','67% группы · +1 к сентябрю')+stat('Многодетные семьи',14,'users','58% группы · +1 к сентябрю');
document.getElementById('secondary').innerHTML=stat('Сироты',1,'users','4% от числа студентов')+stat('Малообеспеченные семьи',0,'book','−2 к сентябрю')+stat('Академический отпуск',0,'cal','Без изменений к сентябрю');
document.getElementById('bars').innerHTML=[data[8],data[3],data[5],data[7],data[6]].map(([n,v])=>`<div class="metric-row"><span>${n}</span><div class="track"><i style="width:${v/24*100}%"></i></div><b>${v}<span style="color:#b5bac7;font-weight:400"> / 24</span></b></div>`).join('');
document.getElementById('dataTable').innerHTML='<table class="sourcetable"><thead><tr><th>Показатель</th><th>Количество</th><th>Доля группы</th><th>К сентябрю</th></tr></thead><tbody>'+data.map(([n,v])=>{let c=changes.find(c=>c[0]===n);let d=c?c[2]-c[1]:null;return `<tr><td style="color:#3f4960">${n}</td><td><b>${v}</b></td><td><span class="badge">${Math.round(v/24*100)}%</span></td><td>${d===null?'Нет данных':d===0?'Без изменений':(d>0?'+':'')+d}</td></tr>`}).join('')+'</tbody></table>';
function chart(index){let [name,a,b]=changes[index];document.getElementById('chartTitle').textContent=name;document.getElementById('delta').textContent=a===b?'Без изменений':(b>a?'+':'')+(b-a)+' к сентябрю';document.getElementById('chartButtons').innerHTML=changes.map(([n],i)=>`<button class="btn ${i===index?'selected':''}" onclick="chart(${i})">${n}</button>`).join('');document.getElementById('monthChart').innerHTML=[[a,'Сентябрь'],[b,'Октябрь']].map(([v,m])=>`<div class="monthcol"><b>${v}</b><div class="column" style="height:${v/24*155}px;opacity:${m==='Сентябрь'?'.45':'1'}"></div><span>${m}</span></div>`).join('');document.getElementById('chartNote').textContent=index===0?'В общежитии: 6 юношей и 10 девушек — всего 16 студентов в октябре.':'Количество студентов в категории; изменения не являются оценкой благополучия группы.'}
async function ask(q){
 q=q.trim();if(!q)return;
 const box=document.getElementById('messages');
 const append=(cls,text)=>{const el=document.createElement('div');el.className=cls;el.textContent=text;box.append(el);return el};
 append('message user',q);document.getElementById('question').value='';
 const answer=append('message','Готовлю ответ…');
 try{const response=await fetch('/api/assistant',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});const result=await response.json();if(!response.ok)throw new Error(result.error||'Ошибка сервера');answer.textContent=result.answer;}
 catch(error){answer.textContent='Не удалось получить ответ. Проверьте, что Python-сервер запущен. '+error.message;}
 answer.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function downloadReport(){window.location.href='/reports/social-passport.csv'}
chart(0);if(location.hash)go(location.hash.slice(1));

(function(){
const button=document.getElementById('themeToggle');
function update(){const dark=document.documentElement.dataset.theme==='dark';button.textContent=dark?'☀ Светлая тема':'☾ Тёмная тема';button.setAttribute('aria-pressed',String(dark));button.title=dark?'Переключить на светлую тему':'Переключить на тёмную тему';}
button.addEventListener('click',()=>{const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=theme;try{localStorage.setItem('rki25-theme',theme);}catch(e){}update();});
update();
})();
