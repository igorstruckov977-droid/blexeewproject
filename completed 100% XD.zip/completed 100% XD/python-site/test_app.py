import csv
import io
import unittest
from app import app


class AppTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_page_and_assets(self):
        page = self.client.get('/')
        self.assertEqual(page.status_code, 200)
        self.assertIn('РКИ-25', page.get_data(as_text=True))
        self.assertNotIn('{{', page.get_data(as_text=True))
        for path in ('style.css', 'app.js', 'assets/aityyn-beaver.png'):
            response = self.client.get('/static/' + path)
            self.assertEqual(response.status_code, 200)
            response.close()

    def test_group_consistency(self):
        group = self.client.get('/api/group').get_json()
        values = dict(group['metrics'])
        self.assertEqual(values['Девушки'] + values['Юноши'], values['Всего обучающихся'])
        for name, before, after in group['changes']:
            self.assertEqual(after, values[name])

    def test_assistant(self):
        result = self.client.post('/api/assistant', json={'question': 'Что изменилось?'})
        self.assertEqual(result.status_code, 200)
        self.assertIn('15 → 16', result.get_json()['answer'])
        result = self.client.post('/api/assistant', json={'question': 'Какие оценки?'})
        self.assertIn('Сведений об оценках', result.get_json()['answer'])
        for payload in ({}, [], {'question': ''}, {'question': 5}, {'question': 'x' * 2001}):
            self.assertEqual(self.client.post('/api/assistant', json=payload).status_code, 400)

    def test_csv(self):
        response = self.client.get('/reports/social-passport.csv')
        self.assertIn('attachment', response.headers['Content-Disposition'])
        rows = list(csv.reader(io.StringIO(response.data.decode('utf-8-sig')), delimiter=';'))
        self.assertIn(['Девушки', '13', '54%'], rows)
        self.assertIn(['Проживают в общежитии', '16', '67%'], rows)
        response.close()


if __name__ == '__main__':
    unittest.main()
