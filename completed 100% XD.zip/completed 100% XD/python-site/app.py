"""Куратор AI: Python/Flask, социальный паспорт РКИ-25."""
import csv
import io
import json
from pathlib import Path
from flask import Flask, jsonify, render_template, request, send_file

ROOT = Path(__file__).resolve().parent
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024


def load_group():
    """Единый источник показателей для интерфейса, API и отчётов."""
    return json.loads((ROOT / 'data.json').read_text(encoding='utf-8'))


def assistant_answer(question, group):
    q = question.casefold()
    values = dict(group['metrics'])
    if 'общежит' in q:
        return (f"В октябре в общежитии проживают {values['Проживают в общежитии']} студентов "
                "РКИ-25: 6 юношей и 10 девушек. Это 67% группы. В сентябре было 15.")
    if any(word in q for word in ('измен', 'динами', 'сентябр')):
        rows = '\n'.join(f'• {name}: {before} → {after}.' for name, before, after in group['changes'])
        return 'Сентябрь → октябрь:\n' + rows + '\nСентябрьские значения восстановлены по изменениям на фото.'
    if any(word in q for word in ('социал', 'сем', 'сирот', 'сво')):
        names = ['Многодетные семьи', 'Малообеспеченные семьи', 'Сироты', 'Семьи участников СВО']
        return ('Социальные показатели за октябрь:\n' + '\n'.join(f'• {n} — {values[n]}.' for n in names)
                + '\nКатегории могут пересекаться; их нельзя складывать в общее число студентов.')
    if any(word in q for word in ('групп', 'состав', 'куратор', 'девуш', 'юнош', 'студент')):
        return (f"{group['name']}: {values['Всего обучающихся']} студента — "
                f"{values['Девушки']} девушек и {values['Юноши']} юношей. "
                f"Несовершеннолетних: {values['Несовершеннолетние']}. "
                f"Куратор — {group['curator']}. Данные за {group['period']}.")
    return ('Доступны ответы о составе группы, общежитии, социальных категориях и изменениях за месяц. '
            'Сведений об оценках, посещаемости и отдельных студентах в материалах нет. '
            'Это помощник по готовым сценариям, языковая модель не подключена.')


@app.get('/')
def index():
    group = load_group()
    return render_template('index.html', group=group)


@app.get('/api/group')
def group_data():
    return jsonify(load_group())


@app.post('/api/assistant')
def assistant():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify(error='Ожидается JSON с полем question.'), 400
    question = payload.get('question')
    if not isinstance(question, str) or not question.strip() or len(question) > 2000:
        return jsonify(error='Введите вопрос от 1 до 2000 символов.'), 400
    return jsonify(answer=assistant_answer(question.strip(), load_group()))


@app.get('/reports/social-passport.csv')
def report():
    group = load_group()
    output = io.StringIO(newline='')
    writer = csv.writer(output, delimiter=';')
    writer.writerow([group['name'], group['period'], 'Куратор: ' + group['curator']])
    writer.writerow(['Показатель', 'Количество', 'Доля группы'])
    total = dict(group['metrics'])['Всего обучающихся']
    for name, value in group['metrics']:
        writer.writerow([name, value, f'{int(value / total * 100 + 0.5)}%'])
    writer.writerow(['Источник', group['source']])
    writer.writerow(['Примечание', 'Категории могут пересекаться'])
    return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),
                     mimetype='text/csv; charset=utf-8', as_attachment=True,
                     download_name='RKI-25-social-passport-2026-10.csv')


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=False)
