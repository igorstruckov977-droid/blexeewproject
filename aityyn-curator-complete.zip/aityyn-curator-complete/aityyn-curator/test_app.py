import csv
import io
import json
import re
import sqlite3
import tempfile
import unittest
from pathlib import Path
from app import create_app
from manage import restore_backup

class CuratorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.temp.name)/'test.sqlite3')
        self.app=create_app({'TESTING':True,'DATABASE':self.path,'SECRET_KEY':'test-secret-only'})
        self.client=self.app.test_client()
        self.client.get('/setup')
        self.post('/setup',{'username':'curator','password':'test-password','confirm':'test-password'})
        self.client.get('/login')
        self.post('/login',{'username':'curator','password':'test-password'})

    def tearDown(self):self.temp.cleanup()

    def post(self,url,data):
        with self.client.session_transaction() as s:token=s['csrf']
        return self.client.post(url,data={**data,'csrf':token})

    def sql(self,query,args=()):
        with sqlite3.connect(self.path) as conn:return conn.execute(query,args).fetchall()

    def form(self,month):
        html=self.client.get('/attendance?month='+month).get_data(as_text=True)
        fields={'month':month,'revision':re.search(r'name="revision" value="(\d+)"',html)[1]}
        for name,options in re.findall(r'<select[^>]*name="(mark_[^"]+)"[^>]*>(.*?)</select>',html,re.S):
            fields[name]=re.search(r'<option value="([^"]*)" selected>',options)[1]
        return fields

    def test_pages_and_removed_bot(self):
        for url in ['/','/attendance','/students','/passport?month=2026-10','/admin','/reports']:
            r=self.client.get(url);self.assertEqual(r.status_code,200,url)
            self.assertNotIn('Куратор AI',r.get_data(as_text=True))
            self.assertNotIn('/api/assistant',r.get_data(as_text=True))
        self.assertEqual(self.client.post('/api/assistant',data={'csrf':'bad'}).status_code,400)
        self.assertEqual(self.client.get('/api/assistant').status_code,404)

    def test_auth_and_csrf(self):
        self.assertEqual(self.client.post('/students',data={'name':'Test Name'}).status_code,400)
        self.post('/logout',{})
        for url in ['/','/attendance','/reports','/backup','/reports/attendance.csv']:
            self.assertEqual(self.client.get(url).status_code,302)
        self.assertEqual(self.client.get('/setup').status_code,302)
        self.client.get('/login')
        for _ in range(5):self.post('/login',{'username':'curator','password':'wrong-password'})
        self.assertGreater(self.sql('SELECT locked_until FROM admins')[0][0],0)
        self.assertNotIn('test-password',self.sql('SELECT password FROM admins')[0][0])

    def test_save_persistence_validation_and_conflict(self):
        fields=self.form('2026-11');key='mark_1_2026-11-02'
        fields[key]='absent'
        self.assertEqual(self.post('/attendance',fields).status_code,302)
        self.assertEqual(self.sql('SELECT status FROM attendance WHERE student_id=1 AND date=?',('2026-11-02',))[0][0],'absent')
        self.assertEqual(self.post('/attendance',fields).status_code,409)
        fields=self.form('2026-11');fields[key]='nonsense'
        self.assertEqual(self.post('/attendance',fields).status_code,400)
        fields=self.form('2026-11');del fields[key]
        self.assertEqual(self.post('/attendance',fields).status_code,400)
        create_app({'TESTING':True,'DATABASE':self.path,'SECRET_KEY':'test-secret-only'})
        self.assertEqual(self.sql('SELECT status FROM attendance WHERE student_id=1 AND date=?',('2026-11-02',))[0][0],'absent')
        self.assertEqual(self.sql("SELECT COUNT(*) FROM attendance WHERE date>='2026-11-09'")[0][0],0)

    def test_source_import_and_report_counts(self):
        self.assertEqual(self.sql('SELECT COUNT(*) FROM students')[0][0],22)
        self.assertEqual(dict(self.sql("SELECT status,COUNT(*) FROM attendance WHERE date LIKE '2026-10%' GROUP BY status")),{'present':419,'absent':14,'sick':57,'excused':9})
        result=self.client.get('/reports/attendance.csv?month=2026-10')
        rows=list(csv.reader(io.StringIO(result.data.decode('utf-8-sig')),delimiter=';'))
        self.assertEqual([int(x) for x in rows[-1][-6:]],[419,14,57,0,9,95])
        self.assertEqual(len(rows),25)
        self.assertNotIn('Без отметки',','.join(rows[-1][-6:]))

    def test_new_month_archive_roster_calendar(self):
        self.post('/students',{'id':'1','name':'Авелова Туулуктаана Ивановна','active':'0'})
        self.client.get('/attendance?month=2027-01')
        self.assertEqual(self.sql("SELECT COUNT(*) FROM roster WHERE month='2027-01'")[0][0],21)
        self.assertEqual(self.sql("SELECT COUNT(*) FROM roster WHERE month='2026-10'")[0][0],22)
        fields=self.form('2026-11')
        days=[r[0] for r in self.sql("SELECT date FROM days WHERE date LIKE '2026-11%' AND teaching=1 AND date!='2026-11-02'")]
        self.assertEqual(self.post('/admin',{'action':'calendar','month':'2026-11','revision':fields['revision'],'teaching':days}).status_code,302)
        self.assertEqual(self.sql("SELECT COUNT(*) FROM attendance WHERE date='2026-11-02'")[0][0],20)
        self.assertNotIn('mark_1_2026-11-02',self.form('2026-11'))
        self.assertEqual(self.post('/attendance',fields).status_code,400)

    def test_metrics_and_safe_export(self):
        vals=[24,11,13,15,0,14,1,3,16,0]
        data={'month':'2026-11',**{f'metric_{i}':str(v) for i,v in enumerate(vals)}}
        self.assertEqual(self.post('/passport',data).status_code,302)
        self.assertEqual(self.sql("SELECT COUNT(*) FROM metrics WHERE month='2026-10'")[0][0],10)
        data['metric_0']='23';self.assertEqual(self.post('/passport',data).status_code,400)
        self.post('/students',{'id':'1','name':'=SUM(1,2)','active':'1'})
        response=self.client.get('/reports/attendance.csv?month=2026-10').data.decode('utf-8-sig')
        self.assertIn("'=SUM(1,2)",response)
        self.assertEqual(self.client.get('/attendance?month=2026-99').status_code,400)

    def test_backup_restore_atomic(self):
        data=self.client.get('/backup').get_json()
        self.assertNotIn('admins',data)
        backup=Path(self.temp.name)/'backup.json';backup.write_text(json.dumps(data))
        self.post('/students',{'name':'Новый Студент Тестовый'})
        restore_backup(backup,self.path)
        self.assertEqual(self.sql('SELECT COUNT(*) FROM students')[0][0],22)
        data['attendance'][0]['status']='bad'
        backup.write_text(json.dumps(data))
        with self.assertRaises(sqlite3.IntegrityError):restore_backup(backup,self.path)
        self.assertEqual(self.sql('SELECT COUNT(*) FROM students')[0][0],22)

if __name__=='__main__':unittest.main()
