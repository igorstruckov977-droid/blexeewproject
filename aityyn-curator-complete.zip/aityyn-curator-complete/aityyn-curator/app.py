"""Айтыын - Куратор. Local Flask application with a persistent SQLite journal."""
import calendar
import csv
import io
import json
import os
import re
import secrets
import sqlite3
import time
from collections import Counter
from datetime import date, timedelta
from functools import wraps
from pathlib import Path
from schedule_import import read_schedule

from flask import Flask, abort, flash, g, redirect, render_template, request, send_file, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

ROOT = Path(__file__).resolve().parent
STATUSES = {'present': ('Я', 'Явка'), 'absent': ('П', 'Прогул'), 'sick': ('Б', 'Болезнь'),
            'individual': ('И', 'Индивидуальный график'), 'excused': ('У', 'Уважительная причина')}
METRICS = ['Всего обучающихся', 'Юноши', 'Девушки', 'Несовершеннолетние',
           'Малообеспеченные семьи', 'Многодетные семьи', 'Сироты',
           'Семьи участников СВО', 'Проживают в общежитии', 'Академический отпуск']
MONTHS = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь']


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.update(DATABASE=str(ROOT / 'instance' / 'curator.sqlite3'),
                      MAX_CONTENT_LENGTH=12 * 1024 * 1024,
                      SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                      SESSION_COOKIE_SECURE=os.getenv('CURATOR_HTTPS') == '1',
                      PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
    if test_config:
        app.config.update(test_config)
    Path(app.config['DATABASE']).parent.mkdir(parents=True, exist_ok=True)
    if not app.config.get('SECRET_KEY'):
        key = Path(app.config['DATABASE']).parent / 'secret.key'
        if not key.exists():
            try:
                with key.open('x') as f:
                    f.write(secrets.token_hex(32))
                key.chmod(0o600)
            except FileExistsError:
                pass
        app.config['SECRET_KEY'] = os.getenv('CURATOR_SECRET') or key.read_text().strip()

    def db():
        if 'db' not in g:
            g.db = sqlite3.connect(app.config['DATABASE'], timeout=15)
            g.db.row_factory = sqlite3.Row
            g.db.execute('PRAGMA foreign_keys=ON')
        return g.db

    @app.teardown_appcontext
    def close_db(_):
        conn = g.pop('db', None)
        if conn is not None:
            conn.close()

    with app.app_context():
        db().executescript('''
          CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY CHECK(id=1), username TEXT NOT NULL, password TEXT NOT NULL, failures INTEGER NOT NULL DEFAULT 0, locked_until REAL NOT NULL DEFAULT 0);
          CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY, name TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS months (month TEXT PRIMARY KEY, revision INTEGER NOT NULL DEFAULT 0);
          CREATE TABLE IF NOT EXISTS roster (month TEXT NOT NULL REFERENCES months(month), student_id INTEGER NOT NULL REFERENCES students(id), PRIMARY KEY(month,student_id));
          CREATE TABLE IF NOT EXISTS days (date TEXT PRIMARY KEY, teaching INTEGER NOT NULL CHECK(teaching IN (0,1)));
          CREATE TABLE IF NOT EXISTS attendance (student_id INTEGER NOT NULL REFERENCES students(id), date TEXT NOT NULL REFERENCES days(date), status TEXT NOT NULL CHECK(status IN ('present','absent','sick','individual','excused')), PRIMARY KEY(student_id,date));
          CREATE TABLE IF NOT EXISTS metrics (month TEXT NOT NULL, name TEXT NOT NULL, value INTEGER NOT NULL CHECK(value>=0), PRIMARY KEY(month,name));
          CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, action TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS schedule (id INTEGER PRIMARY KEY, group_code TEXT NOT NULL, week TEXT NOT NULL, lesson_date TEXT NOT NULL, day TEXT NOT NULL, pair_no INTEGER NOT NULL, time TEXT NOT NULL, subject TEXT NOT NULL, teacher TEXT NOT NULL DEFAULT '', room TEXT NOT NULL DEFAULT '', source TEXT NOT NULL, UNIQUE(group_code,week,lesson_date,pair_no));
        ''')
        if not db().execute("SELECT 1 FROM settings WHERE key='initialized'").fetchone():
            seed = json.loads((ROOT / 'seed' / 'initial.json').read_text(encoding='utf-8'))
            with db():
                for k, v in {**seed['group'], 'source_note': seed['source_note'], 'source_totals': json.dumps(seed['source_totals']), 'initialized': '1', 'reviewed': '0'}.items():
                    db().execute('INSERT INTO settings VALUES (?,?)', (k, v))
                db().executemany('INSERT INTO students(id,name) VALUES (?,?)', [(s['id'], s['name']) for s in seed['students']])
                for m in ['2026-10', '2026-11']:
                    db().execute('INSERT INTO months(month) VALUES (?)', (m,))
                    db().execute('INSERT INTO roster SELECT ?,id FROM students', (m,))
                db().executemany('INSERT INTO days VALUES (?,?)', [(d['date'], int(d['teaching'])) for d in seed['days']])
                db().executemany('INSERT INTO attendance VALUES (?,?,?)', [(r['student_id'], r['date'], r['status']) for r in seed['attendance']])
                db().executemany('INSERT INTO metrics VALUES (?,?,?)', [('2026-10', k, v) for k, v in seed['metrics'].items()])

    def settings():
        return {r['key']: r['value'] for r in db().execute('SELECT * FROM settings')}

    def log(text):
        db().execute('INSERT INTO audit(action) VALUES (?)', (text,))

    def month_arg(value=None):
        m = value or request.values.get('month', '2026-11')
        if not re.fullmatch(r'20\d{2}-(0[1-9]|1[0-2])', m):
            abort(400, 'Выберите месяц с 2000 по 2099 год.')
        return m

    def month_days(m):
        y, mo = map(int, m.split('-'))
        return [date(y, mo, d) for d in range(1, calendar.monthrange(y, mo)[1] + 1)]

    def ensure_month(m):
        if not db().execute('SELECT 1 FROM months WHERE month=?', (m,)).fetchone():
            with db():
                db().execute('INSERT INTO months(month) VALUES (?)', (m,))
                db().execute('INSERT INTO roster SELECT ?,id FROM students', (m,))
                db().executemany('INSERT OR IGNORE INTO days VALUES (?,?)', [(d.isoformat(), int(d.weekday() != 6)) for d in month_days(m)])

    def journal(m):
        ensure_month(m)
        students = db().execute('SELECT s.* FROM students s JOIN roster r ON r.student_id=s.id WHERE r.month=? ORDER BY s.id', (m,)).fetchall()
        days = db().execute('SELECT * FROM days WHERE substr(date,1,7)=? ORDER BY date', (m,)).fetchall()
        marks = {(r['student_id'], r['date']): r['status'] for r in db().execute('SELECT a.* FROM attendance a JOIN roster r ON r.student_id=a.student_id AND r.month=substr(a.date,1,7) JOIN days d ON d.date=a.date WHERE r.month=? AND d.teaching=1', (m,))}
        totals = Counter(marks.values())
        daily = {d['date']: Counter(marks.get((s['id'], d['date'])) for s in students) for d in days}
        rows = {s['id']: Counter(marks.get((s['id'], d['date'])) for d in days if d['teaching']) for s in students}
        slots = len(students) * sum(d['teaching'] for d in days)
        return dict(students=students, days=days, marks=marks, totals=totals, daily=daily, rows=rows,
                    unmarked=slots-len(marks), marked=len(marks), slots=slots,
                    revision=db().execute('SELECT revision FROM months WHERE month=?', (m,)).fetchone()[0])

    def auth_required(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not session.get('admin'):
                return redirect(url_for('login'))
            return fn(*args, **kwargs)
        return wrapped

    @app.before_request
    def protect():
        if request.endpoint == 'static':
            return
        if 'csrf' not in session:
            session['csrf'] = secrets.token_hex(24)
        if request.method == 'POST':
            token = request.form.get('csrf', '')
            if not secrets.compare_digest(session['csrf'], token):
                abort(400, 'Форма устарела. Обновите страницу и повторите действие.')
        if request.endpoint not in ('setup', 'static') and not db().execute('SELECT 1 FROM admins').fetchone():
            return redirect(url_for('setup'))

    @app.after_request
    def headers(response):
        if request.endpoint != 'static':
            response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        return response

    @app.context_processor
    def context():
        return dict(group=settings(), statuses=STATUSES, csrf=session.get('csrf', ''),
                    month_label=lambda m: f'{MONTHS[int(m[5:])-1]} {m[:4]}')

    @app.route('/setup', methods=['GET', 'POST'])
    def setup():
        if db().execute('SELECT 1 FROM admins').fetchone():
            return redirect(url_for('login'))
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            if not 3 <= len(username) <= 40 or not 8 <= len(password) <= 128:
                flash('Логин: 3-40 символов. Пароль: 8-128 символов.', 'error')
            elif password != request.form.get('confirm'):
                flash('Пароли не совпадают.', 'error')
            else:
                try:
                    with db():
                        db().execute('INSERT INTO admins(id,username,password) VALUES (1,?,?)', (username, generate_password_hash(password)))
                        log('Создан аккаунт администратора')
                    session.clear()
                    flash('Аккаунт создан. Войдите с вашим логином и паролем.', 'success')
                    return redirect(url_for('login'))
                except sqlite3.IntegrityError:
                    return redirect(url_for('login'))
        return render_template('auth.html', setup=True)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if session.get('admin'):
            return redirect(url_for('overview'))
        if request.method == 'POST':
            admin = db().execute('SELECT * FROM admins').fetchone()
            if admin['locked_until'] > time.time():
                flash('Слишком много попыток. Подождите минуту.', 'error')
            elif (secrets.compare_digest(request.form.get('username', '').encode(), admin['username'].encode())
                  and check_password_hash(admin['password'], request.form.get('password', ''))):
                with db():
                    db().execute('UPDATE admins SET failures=0,locked_until=0')
                session.clear()
                session['admin'] = True
                session['csrf'] = secrets.token_hex(24)
                session.permanent = True
                return redirect(url_for('overview'))
            else:
                failures = admin['failures']+1
                with db():
                    db().execute('UPDATE admins SET failures=?,locked_until=?', (0 if failures >= 5 else failures, time.time()+60 if failures >= 5 else 0))
                flash('Неверный логин или пароль.', 'error')
        return render_template('auth.html', setup=False)

    @app.post('/logout')
    @auth_required
    def logout():
        session.clear()
        return redirect(url_for('login'))

    @app.get('/')
    @auth_required
    def overview():
        m = month_arg()
        j = journal(m)
        latest = db().execute('SELECT MAX(month) FROM metrics WHERE month<=?', (m,)).fetchone()[0]
        metrics = dict(db().execute('SELECT name,value FROM metrics WHERE month=?', (latest,))) if latest else {}
        return render_template('overview.html', month=m, j=j, metrics=metrics, metrics_month=latest, page='overview')

    @app.route('/attendance', methods=['GET', 'POST'])
    @auth_required
    def attendance():
        m = month_arg()
        j = journal(m)
        if request.method == 'POST':
            valid_keys = {f'mark_{s["id"]}_{d["date"]}' for s in j['students'] for d in j['days'] if d['teaching']}
            submitted = {k for k in request.form if k.startswith('mark_')}
            if submitted != valid_keys or any(request.form[k] not in ('', *STATUSES) for k in submitted):
                abort(400, 'Неверные или неполные отметки. Обновите журнал.')
            try:
                revision = int(request.form.get('revision', '-1'))
            except ValueError:
                abort(400)
            with db():
                changed = db().execute('UPDATE months SET revision=revision+1 WHERE month=? AND revision=?', (m, revision))
                if changed.rowcount != 1:
                    abort(409, 'Журнал изменён в другой вкладке. Обновите страницу перед сохранением.')
                for s in j['students']:
                    for d in j['days']:
                        if d['teaching']:
                            mark = request.form[f'mark_{s["id"]}_{d["date"]}']
                            if mark:
                                db().execute('INSERT INTO attendance VALUES (?,?,?) ON CONFLICT(student_id,date) DO UPDATE SET status=excluded.status', (s['id'], d['date'], mark))
                            else:
                                db().execute('DELETE FROM attendance WHERE student_id=? AND date=?', (s['id'], d['date']))
                log('Сохранена посещаемость за '+m)
            flash('Посещаемость сохранена.', 'success')
            return redirect(url_for('attendance', month=m))
        return render_template('attendance.html', month=m, j=j, page='attendance')

    @app.route('/students', methods=['GET', 'POST'])
    @auth_required
    def students():
        if request.method == 'POST':
            if request.form.get('action') == 'delete':
                sid=request.form.get('id','')
                student=db().execute('SELECT name FROM students WHERE id=?',(sid,)).fetchone()
                if not student:abort(404)
                with db():
                    db().execute('DELETE FROM attendance WHERE student_id=?',(sid,))
                    db().execute('DELETE FROM roster WHERE student_id=?',(sid,))
                    db().execute('DELETE FROM students WHERE id=?',(sid,))
                    log('Удалён студент: '+student['name'])
                flash('Студент и его прошлые отметки удалены.', 'success')
                return redirect(url_for('students'))
            name = request.form.get('name', '').strip()
            if not 3 <= len(name) <= 160 or any(ord(c)<32 for c in name):
                abort(400, 'Введите ФИО длиной от 3 до 160 символов.')
            sid = request.form.get('id')
            with db():
                if sid:
                    result = db().execute('UPDATE students SET name=? WHERE id=?', (name,sid))
                    if not result.rowcount:
                        abort(404)
                    log('Изменён студент №'+str(sid))
                else:
                    db().execute('INSERT INTO students(name) VALUES (?)', (name,))
                    log('Добавлен студент')
            flash('Данные студента сохранены. Состав существующего месяца меняется в админ-панели.', 'success')
            return redirect(url_for('students'))
        return render_template('students.html', students=db().execute('SELECT * FROM students ORDER BY id').fetchall(), page='students')

    @app.route('/schedule', methods=['GET','POST'])
    @auth_required
    def schedule():
        group_code=request.values.get('group','РКИ-25').strip().upper()
        if not re.fullmatch(r'[А-ЯЁA-Z0-9-]{2,24}',group_code):abort(400,'Проверьте название группы.')
        if request.method=='POST':
            upload=request.files.get('file')
            if not upload or not upload.filename or not upload.filename.lower().endswith('.xlsx'):
                abort(400,'Выберите файл .xlsx.')
            try:
                start,end,source,lessons=read_schedule(upload,group_code)
            except (ValueError, OSError, KeyError) as e:
                abort(400,str(e))
            week=start+'_'+end
            with db():
                db().execute('DELETE FROM schedule WHERE group_code=? AND week=?',(group_code,week))
                db().executemany('INSERT INTO schedule(group_code,week,lesson_date,day,pair_no,time,subject,teacher,room,source) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    [(group_code,week,x['date'],x['day'],x['pair_no'],x['time'],x['subject'],x['teacher'],x['room'],secure_filename(upload.filename)[:160]) for x in lessons])
                log(f'Импорт расписания {group_code} {start} - {end} ({len(lessons)} занятий)')
            flash(f'Расписание {group_code} загружено: {len(lessons)} занятий, {start} - {end}.', 'success')
            return redirect(url_for('schedule',group=group_code,week=week))
        weeks=db().execute('SELECT DISTINCT week FROM schedule WHERE group_code=? ORDER BY week DESC',(group_code,)).fetchall()
        week=request.args.get('week') or (weeks[0]['week'] if weeks else '')
        if week and not re.fullmatch(r'20\d{2}-\d{2}-\d{2}_20\d{2}-\d{2}-\d{2}',week):abort(400)
        lessons=db().execute('SELECT * FROM schedule WHERE group_code=? AND week=? ORDER BY day, pair_no',(group_code,week)).fetchall() if week else []
        lessons_by_day={}
        for lesson in lessons:lessons_by_day.setdefault(lesson['lesson_date'],[]).append(lesson)
        month_for_week=week[:7] if week else ''
        roster=db().execute('SELECT s.name FROM students s JOIN roster r ON r.student_id=s.id WHERE r.month=? ORDER BY s.name',(month_for_week,)).fetchall() if month_for_week else []
        groups=db().execute('SELECT DISTINCT group_code FROM schedule ORDER BY group_code').fetchall()
        return render_template('schedule.html',page='schedule',group_code=group_code,groups=groups,weeks=weeks,week=week,lessons_by_day=lessons_by_day,roster=roster)

    @app.route('/passport', methods=['GET', 'POST'])
    @auth_required
    def passport():
        m = month_arg()
        if request.method == 'POST':
            try:
                values = {n: int(request.form[f'metric_{i}']) for i, n in enumerate(METRICS)}
            except (KeyError, ValueError):
                abort(400, 'Все показатели должны быть целыми числами.')
            total = values[METRICS[0]]
            if not 0 <= total <= 10000 or any(v < 0 or v > total for v in values.values()) or values['Юноши'] + values['Девушки'] != total:
                abort(400, 'Проверьте значения: юноши + девушки = всего, каждый показатель от 0 до общего числа.')
            with db():
                db().executemany('INSERT INTO metrics VALUES (?,?,?) ON CONFLICT(month,name) DO UPDATE SET value=excluded.value', [(m,n,v) for n,v in values.items()])
                log('Обновлён социальный паспорт за '+m)
            flash('Социальный паспорт сохранён.', 'success')
            return redirect(url_for('passport', month=m))
        values = dict(db().execute('SELECT name,value FROM metrics WHERE month=?', (m,)))
        return render_template('passport.html', month=m, values=values, metric_names=METRICS, page='passport')

    @app.route('/admin', methods=['GET', 'POST'])
    @auth_required
    def admin():
        m = month_arg()
        j = journal(m)
        if request.method == 'POST':
            action = request.form.get('action')
            with db():
                if action == 'settings':
                    for key in ['name','curator']:
                        value = request.form.get(key,'').strip()
                        if not 1 <= len(value) <= 160:
                            abort(400, 'Заполните название группы и имя куратора.')
                        db().execute('UPDATE settings SET value=? WHERE key=?', (value,key))
                    db().execute("UPDATE settings SET value=? WHERE key='reviewed'", ('1' if request.form.get('reviewed') else '0',))
                    log('Обновлены настройки группы')
                elif action == 'calendar':
                    updated=db().execute('UPDATE months SET revision=revision+1 WHERE month=? AND revision=?',(m,request.form.get('revision','')))
                    if updated.rowcount != 1:
                        abort(409, 'Месяц изменился. Обновите страницу.')
                    dates={d['date'] for d in j['days']}
                    selected=set(request.form.getlist('teaching'))
                    if not selected <= dates:
                        abort(400)
                    for d in dates:
                        db().execute('UPDATE days SET teaching=? WHERE date=?', (int(d in selected),d))
                    log('Обновлён учебный календарь за '+m)
                elif action == 'roster':
                    updated=db().execute('UPDATE months SET revision=revision+1 WHERE month=? AND revision=?',(m,request.form.get('revision','')))
                    if updated.rowcount != 1:
                        abort(409, 'Месяц изменился. Обновите страницу.')
                    valid={str(r[0]) for r in db().execute('SELECT id FROM students')}
                    selected=set(request.form.getlist('student'))
                    if not selected <= valid:
                        abort(400)
                    db().execute('DELETE FROM roster WHERE month=?',(m,))
                    db().executemany('INSERT INTO roster VALUES (?,?)',[(m,int(s)) for s in selected])
                    log('Обновлён состав журнала за '+m)
                elif action == 'password':
                    user=db().execute('SELECT * FROM admins').fetchone()
                    password=request.form.get('password','')
                    if not check_password_hash(user['password'], request.form.get('current','')):
                        abort(400,'Текущий пароль неверен.')
                    if not 8 <= len(password) <= 128 or password != request.form.get('confirm'):
                        abort(400,'Новый пароль должен содержать 8-128 символов. Повтор должен совпадать.')
                    db().execute('UPDATE admins SET password=?',(generate_password_hash(password),))
                    log('Изменён пароль администратора')
                else:
                    abort(400)
            flash('Изменения сохранены.', 'success')
            return redirect(url_for('admin', month=m))
        return render_template('admin.html', month=m, j=j, all_students=db().execute('SELECT * FROM students ORDER BY id').fetchall(), roster_ids={s['id'] for s in j['students']}, audit=db().execute('SELECT * FROM audit ORDER BY id DESC LIMIT 8').fetchall(), page='admin')

    @app.get('/reports')
    @auth_required
    def reports():
        m=month_arg();j=journal(m)
        source=json.loads(settings()['source_totals']).get(m)
        return render_template('reports.html', month=m, j=j, source=source, page='reports')

    def csv_response(rows, filename):
        output=io.StringIO(newline='');writer=csv.writer(output,delimiter=';')
        for row in rows:
            # Prevent spreadsheet formulas in user-controlled labels and names.
            writer.writerow(["'"+v if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')) else v for v in row])
        return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')),mimetype='text/csv; charset=utf-8',as_attachment=True,download_name=filename)

    @app.get('/reports/attendance.csv')
    @auth_required
    def attendance_csv():
        m=month_arg();j=journal(m)
        rows=[[settings()['name'],m,'Учёт по дням, не по урокам'],['ФИО']+[d['date'] for d in j['days']]+[v[1] for v in STATUSES.values()]+['Без отметки']]
        for s in j['students']:
            rows.append([s['name']]+[STATUSES[j['marks'][(s['id'],d['date'])]][1] if (s['id'],d['date']) in j['marks'] else ('Без отметки' if d['teaching'] else 'Неучебный день') for d in j['days']]+[j['rows'][s['id']][k] for k in STATUSES]+[j['rows'][s['id']][None]])
        rows.append(['ИТОГО']+['']*len(j['days'])+[j['totals'][k] for k in STATUSES]+[j['unmarked']])
        return csv_response(rows,f'attendance-{m}.csv')

    @app.get('/reports/social-passport.csv')
    @auth_required
    def passport_csv():
        m=month_arg();values=dict(db().execute('SELECT name,value FROM metrics WHERE month=?',(m,)))
        if not values:
            abort(404,'За этот месяц социальный паспорт ещё не заполнен.')
        return csv_response([[settings()['name'],m],['Показатель','Количество']]+[[k,values[k]] for k in METRICS],f'passport-{m}.csv')

    @app.get('/backup')
    @auth_required
    def backup():
        data={table:[dict(r) for r in db().execute('SELECT * FROM '+table)] for table in ['settings','students','months','roster','days','attendance','metrics','audit','schedule']}
        data.update(format='aityyn-curator',version=1)
        return send_file(io.BytesIO(json.dumps(data,ensure_ascii=False,indent=2).encode()),mimetype='application/json',as_attachment=True,download_name='curator-backup.json')

    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(409)
    @app.errorhandler(413)
    def error(e):
        return render_template('error.html', error=e), e.code

    return app


if __name__ == '__main__':
    create_app().run(host='127.0.0.1',port=5000,debug=False)
