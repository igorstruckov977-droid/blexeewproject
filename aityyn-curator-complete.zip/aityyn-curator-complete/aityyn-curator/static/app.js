const themeButton=document.getElementById('themeToggle');
function syncTheme(){const dark=document.documentElement.dataset.theme==='dark';themeButton.textContent=dark?'☀ Светлая тема':'☾ Тёмная тема';themeButton.setAttribute('aria-pressed',String(dark));}
themeButton.addEventListener('click',()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;try{localStorage.setItem('rki25-theme',t)}catch(e){}syncTheme()});syncTheme();
let dirty=false;const state=document.getElementById('saveState');
function markDirty(){dirty=true;if(state)state.textContent='Есть несохранённые изменения';}
document.querySelectorAll('[data-dirty]').forEach(form=>{form.addEventListener('change',markDirty);form.addEventListener('submit',()=>{dirty=false})});
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue=''}});
function paint(select){select.className='mark '+select.value;}
document.querySelectorAll('.mark').forEach(s=>s.addEventListener('change',()=>paint(s)));
document.getElementById('bulkApply')?.addEventListener('click',()=>{const day=document.getElementById('bulkDay').value;if(!day)return;const status=document.getElementById('bulkStatus').value;let count=0;document.querySelectorAll('.mark').forEach(s=>{if(s.dataset.day===day&&!s.value){s.value=status;paint(s);count++}});if(count){markDirty();state.textContent=`Заполнено ячеек: ${count}. Нажмите «Сохранить посещаемость».`}});
