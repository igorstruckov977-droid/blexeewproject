"""Local maintenance. Stop the server before restoring or resetting a password."""
import argparse
import getpass
import json
import re
import sqlite3
from datetime import date
from pathlib import Path
from werkzeug.security import generate_password_hash

ROOT=Path(__file__).resolve().parent
TABLES={'settings':['key','value'],'students':['id','name'],'months':['month','revision'],
        'roster':['month','student_id'],'days':['date','teaching'],
        'attendance':['student_id','date','status'],'metrics':['month','name','value'],
        'audit':['id','created','action'],'schedule':['id','group_code','week','lesson_date','day','pair_no','time','subject','teacher','room','source']}

def restore_backup(path, database):
    data=json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if data.get('format')!='aityyn-curator' or data.get('version')!=1:
        raise ValueError('Формат резервной копии не поддерживается.')
    data.setdefault('schedule',[])
    for table,cols in TABLES.items():
        if not isinstance(data.get(table),list) or len(data[table])>1000000:
            raise ValueError('Неверный раздел: '+table)
        for row in data[table]:
            if not isinstance(row,dict) or set(row)!=set(cols):
                raise ValueError('Неверные поля: '+table)
            if 'month' in row and not re.fullmatch(r'20\d{2}-(0[1-9]|1[0-2])',str(row['month'])):
                raise ValueError('Неверный месяц')
            if 'date' in row:
                d=date.fromisoformat(row['date'])
                if not 2000<=d.year<=2099:raise ValueError('Неверная дата')
            if table=='students' and (not isinstance(row['name'],str) or not 3<=len(row['name'])<=160):
                raise ValueError('Неверное ФИО')
            if table=='schedule':
                try:date.fromisoformat(row['lesson_date'])
                except (TypeError,ValueError):raise ValueError('Неверная дата расписания')
    keys={r['key'] for r in data['settings']}
    if not {'name','curator','initialized','source_totals','source_note','reviewed'}<=keys:
        raise ValueError('Неполные настройки')
    conn=sqlite3.connect(database)
    conn.execute('PRAGMA foreign_keys=ON')
    try:
        with conn:
            for table in ['schedule','attendance','roster','days','months','students','metrics','settings','audit']:
                conn.execute('DELETE FROM '+table)
            for table,cols in TABLES.items():
                sql=f'INSERT INTO {table} ({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})'
                conn.executemany(sql,[[r[c] for c in cols] for r in data[table]])
            # Historical marks for excluded roster members are deliberately retained.
            conn.execute("INSERT INTO audit(action) VALUES ('Восстановлена резервная копия')")
    finally:
        conn.close()

def main():
    parser=argparse.ArgumentParser(description='Обслуживание Айтыын - Куратор')
    parser.add_argument('command',choices=['reset-password','restore'])
    parser.add_argument('backup',nargs='?')
    args=parser.parse_args()
    database=ROOT/'instance'/'curator.sqlite3'
    if not database.exists():raise SystemExit('Сначала запустите app.py.')
    if args.command=='restore':
        if not args.backup:raise SystemExit('Укажите файл JSON.')
        if input('Остановите сервер. Текущие данные будут заменены. Введите ВОССТАНОВИТЬ: ')!='ВОССТАНОВИТЬ':raise SystemExit('Отменено')
        restore_backup(args.backup,database)
        print('Данные восстановлены. Аккаунт администратора сохранён.')
    else:
        password=getpass.getpass('Новый пароль (8-128 символов): ')
        if not 8<=len(password)<=128 or password!=getpass.getpass('Повтор: '):raise SystemExit('Пароль не подходит или повтор не совпадает.')
        with sqlite3.connect(database) as conn:
            row=conn.execute('SELECT username FROM admins').fetchone()
            if not row:raise SystemExit('Сначала создайте аккаунт при первом запуске.')
            conn.execute('UPDATE admins SET password=?,failures=0,locked_until=0',(generate_password_hash(password),))
        # Rotate the signing key to invalidate existing sessions.
        import secrets
        (database.parent/'secret.key').write_text(secrets.token_hex(32))
        print('Пароль обновлён. Логин:',row[0])

if __name__=='__main__':main()
