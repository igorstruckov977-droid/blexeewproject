"""Read weekly college timetables exported as XLSX."""
import re
from datetime import date, timedelta
from pathlib import Path
from openpyxl import load_workbook

DAY_NAMES={'понедельник':0,'вторник':1,'среда':2,'четверг':3,'пятница':4,'суббота':5,'воскресенье':6}
WEEK=re.compile(r'(\d{1,2})\.(\d{1,2})\s*[-–]\s*(\d{1,2})\.(\d{1,2})\.(20\d{2})')
def read_schedule(fileobj, group_code):
    wb=load_workbook(fileobj,data_only=True,read_only=False)
    ws=wb.active
    if ws.max_row<10 or ws.max_column<4: raise ValueError('Не нашла в таблице расписание.')
    headers={str(ws.cell(9,c).value).strip().upper():c for c in range(1,ws.max_column+1) if ws.cell(9,c).value}
    key=group_code.strip().upper()
    if key not in headers: raise ValueError(f'В выбранном файле нет группы {group_code}.')
    col=headers[key]
    title=' '.join(str(ws.cell(r,1).value or '') for r in (5,6,7))
    match=WEEK.search(title)
    if not match: raise ValueError('Не удалось прочитать даты недели в строке заголовка Excel.')
    d1,m1,d2,m2,year=map(int,match.groups());year=int(year)
    start=date(year,m1,d1);end=date(year,m2,d2)
    if (end-start).days not in range(4,8):raise ValueError('Проверьте даты недели в заголовке файла.')
    range_days=[start+timedelta(days=i) for i in range((end-start).days+1)]
    values=[];day_label=''
    for r in range(10,ws.max_row):
        label=str(ws.cell(r,1).value or '').strip().lower()
        for name in DAY_NAMES:
            if label.startswith(name):day_label=name;break
        pair=ws.cell(r,2).value
        if not isinstance(pair,(int,float)) or not 1<=int(pair)<=10:continue
        subject=str(ws.cell(r,col).value or '').strip()
        if not subject or day_label not in DAY_NAMES:continue
        teacher=str(ws.cell(r+1,col).value or '').strip()
        time_text=str(ws.cell(r,3).value or '').strip()
        room=str(ws.cell(r,col+1).value or ws.cell(r+1,col+1).value or '').strip()
        weekday=DAY_NAMES[day_label]
        lesson_date=next((d for d in range_days if d.weekday()==weekday),None)
        if lesson_date is None:continue
        values.append({'day':day_label.capitalize(),'date':lesson_date.isoformat(),'pair_no':int(pair),
                       'time':time_text,'subject':subject,'teacher':teacher,'room':room})
    if not values:raise ValueError(f'В столбце группы {group_code} не найдено занятий. Проверьте строку с названием группы.')
    if len(values)>1000:raise ValueError('В файле слишком много строк расписания.')
    wb.close()
    return start.isoformat(),end.isoformat(),title,values
