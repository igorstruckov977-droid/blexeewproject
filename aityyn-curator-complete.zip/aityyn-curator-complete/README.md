# Айтыын - Куратор

Python-версия с админ-панелью, журналом посещаемости и импортом недельного расписания XLSX.

## Файлы

- `aityyn-curator/` - приложение Flask, SQLite и README.
- `documents/aityyn_curator_report.docx` - отчёт на 7 страниц.
- `documents/aityyn_curator_presentation.pptx` - презентация на 6 слайдов.
- `documents/pamyatka_evdokia.txt` - памятка Евдокии.
- `example-schedule/weekly-schedule.xlsx` - приложенный пример Excel для импорта.

Распакуйте архив. Откройте PowerShell в папке `aityyn-curator`, где лежит `app.py`, и выполните:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

Затем откройте http://127.0.0.1:5000 и создайте свой аккаунт администратора. Подробности запуска и работы находятся в `aityyn-curator/README.md`. Кнопка «Удалить» стирает старые записи студента.

Пример XLSX импортируется на странице «Расписание». Проверьте период: имя файла говорит 09.11-14.11, а заголовок внутри Excel указывает 02.11-08.11.
